#!/bin/bash

sudo cp fixed2.patch /usr/lib/cgi-bin
cd /home
sudo groupadd memo-group
sudo mkdir memo-home
sudo chown root memo-home
sudo chgrp -R memo-group memo-home
sudo chmod 755 memo-home
cd memo-home
sudo mkdir memo
sudo chown root memo
sudo chgrp -R memo-group memo
sudo chmod 1775 memo
cd /home
USERS=$(sudo ls -l | sed -n '1!p' | awk '{print $3}' | sort -u)
for user in $USERS
do
    if [ $user != "root" ]; then sudo usermod -a -G memo-group $user; fi
done
sudo cp -r /home/*/memo/* /home/memo-home/memo
sudo cp -r /root/memo/* /home/memo-home/memo
cd /usr/lib/cgi-bin
sudo chmod 755 memo.pl
sudo patch < fixed2.patch
