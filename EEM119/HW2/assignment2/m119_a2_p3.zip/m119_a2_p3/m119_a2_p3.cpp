#include <stdio.h>
#include <string>
#include "mbed.h"

DigitalOut tx(PTA10);
InterruptIn rx(PTD2);                       //DigitalIn with interrupts
PwmOut pwm(PTA10);
Serial pc(USBTX, USBRX);
EventQueue queue(32 * EVENTS_EVENT_SIZE);
Thread th;
Timer t;

int PERIOD = 100000;                    //(us)
float DUTY_CYCLE = 0.5;                 //(%)
int start_int;                          //timestamp for when interval begins
int prev_rise;                          //timestamp for when 
int tally = 0;                          //number of times a rise is detected on PTA10 (mod 10)
int time_on = 0;                        //total time PTA10 is on (to calculate D)

//function to execute when rise on PTA10 is detected
void rise_handler()
{
    tally++;
    if(tally == 10)
    {
        int now = t.read_us();
        int T = now - prev_rise;
        float D = ((float) (time_on)) / ((float) (now - start_int));
        pc.printf("mbed> %d, %f\n", T, D);
        tally = 0;
        time_on = 0;
        start_int = now;
    }
    prev_rise = t.read_us();
}

//function to execute when fall on PTA10 is detected
void fall_handler()
{
    time_on += (t.read_us() - prev_rise);
}

int main()
{
    //use event queue in separate thread to asynchronously run asynchronous requests in order (mainly to allow for printf, which cannot be done with just InterruptIn)
    th.start(callback(&queue, &EventQueue::dispatch_forever));
    //on event of voltage rise or fall on digital pin, call "rise_handler()" or "fall_handler()"
    rx.rise(queue.event(rise_handler));
    rx.fall(queue.event(fall_handler));
    t.start();
    start_int = t.read_us();
    pwm.period_us(PERIOD);
    pwm.write(DUTY_CYCLE);
    int T;
    float D;
    string s;
    char buffer;
    //spin check to update period and duty cycle
    while(1)
    {
        ThisThread::sleep_for(5);
        if(pc.readable())
        {
            pwm.write(0.0f);
            buffer = pc.getc();
            //method to handle end of transmission characters
            while(isprint(buffer))
            {
                s += buffer;
                buffer = pc.getc();
            }
            if(s.size())
            {
                //update delays
                if(sscanf(s.c_str(), "%d, %f\n", &T, &D) == 2)
                {
                    PERIOD = T;
                    DUTY_CYCLE = D;
                }
                else
                {
                    pc.printf("mbed> ERROR\n");
                }
            }
            pwm.period_us(PERIOD);
            pwm.write(DUTY_CYCLE);
            s = "";
        }
    }
}

//some code referenced and taken from "https://os.mbed.com/docs/mbed-os/v5.12/apis/eventqueue.html" and "https://os.mbed.com/docs/mbed-os/v5.12/apis/interruptin.html"
//specs is unclear whether milliseconds (ms) or microseconds (us); microseconds (us) chosen

//attempted to have pwm to update pwm through ISR, but bugs with ISR made it incompatible and impossible; gave up and resorted to spin checking (may fail for PERIOD <= 2000 due to printf too slow) (again, not sure if ms or us)
//(also, ISR is incompatible when multiple threads and mutexes in any of them) (ISR is used in "m119_a2_p4" though)
//should-be case: "https://os.mbed.com/forum/bugs-suggestions/topic/28244/?page=1#comment-53612"
//bug report: "https://github.com/ARMmbed/mbed-os/issues/6107"