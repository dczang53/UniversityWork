#include <stdio.h>
#include <string>
#include "mbed.h"

DigitalOut pwm(PTA10);
InterruptIn rx(PTD2);                       //DigitalIn with interrupts
RawSerial pc(USBTX, USBRX);                 //NOTE: changed to RawSerial because ISR handler doesn't allow mutuxes from EventQueue access and Serial reading
EventQueue queue(32 * EVENTS_EVENT_SIZE);
Thread th;
Timer t;

//Default Values
#define PERIOD      100 //(ms)
#define DUTY_CYCLE  0.5 //(%)

int delay0 = PERIOD * (1 - DUTY_CYCLE); //delay for how long PTA10 is OFF
int delay1 = PERIOD * DUTY_CYCLE;       //delay for how long PTA10 is ON
int start_int;                          //timestamp for when interval begins
int prev_rise;                          //timestamp for when 
int tally = 0;                          //number of times a rise is detected on PTA10 (mod 10)
int time_on = 0;                        //total time PTA10 is on (to calculate D)
bool print_error = false;

//function to execute when rise on PTA10 is detected
void rise_handler()
{
    if(print_error)
    {
        pc.printf("mbed> ERROR\n");
        print_error = false;
    }
    tally++;
    if(tally == 10)
    {
        int now = t.read_us();
        int T = now - prev_rise;
        float D = ((float) (time_on)) / ((float) (now - start_int));
        pc.printf("mbed> %d, %f\n", T, D);
        tally = 0;
        time_on = 0;
        start_int = now;
    }
    prev_rise = t.read_us();
}

//function to execute when fall on PTA10 is detected
void fall_handler()
{
    time_on += (t.read_us() - prev_rise);
}

//immediately calls and executes via ISR
void handle_input()
{
    int T;
    float D;
    string s;
    char buffer = pc.getc();
    //method to handle end of transmission characters
    while(isprint(buffer))
    {
        s += buffer;
        buffer = pc.getc();
    }
    //update delays
    if(sscanf(s.c_str(), "%d, %f\n", &T, &D) == 2)
    {
        T = (T / 1000);
        delay0 = T * (1 - D);
        delay1 = T * D;
    }
    else if(s.size())
        print_error = true;
}

int main()
{
    //use event queue in separate thread to asynchronously run asynchronous requests in order (mainly to allow for printf, which cannot be done with just InterruptIn)
    th.start(callback(&queue, &EventQueue::dispatch_forever));
    //on event of voltage rise or fall on digital pin, call "rise_handler()" or "fall_handler()"
    rx.rise(queue.event(rise_handler));
    rx.fall(queue.event(fall_handler));
    //on event of receiver interrupt, call function "handle_input()"
    pc.attach(handle_input, Serial::RxIrq);
    t.start();
    start_int = t.read_us();
    //infinite loop to toggle PTA10 between OFF and ON
    while(1)
    {
        pwm = 1;
        ThisThread::sleep_for(delay1);
        pwm = 0;
        ThisThread::sleep_for(delay0);
    }
}

//some code referenced and taken from "https://os.mbed.com/docs/mbed-os/v5.12/apis/eventqueue.html" and "https://os.mbed.com/docs/mbed-os/v5.12/apis/interruptin.html"

//strange bugs: code was working completely before, but now cannot handle long strings ("asdfasdf" works, but "asdfasdfasdf" doesn't)
//would forward "handle_input" to event queue, but see bug report in comments of "m119_a2_p3" (impossible)
//may be incompatibilities with sscanf and stdio, but no possible complete workaround since necessary dependency on reading input (read from Serial is also the same)
//also strange bug with T values less than 10000; delay get deducted by 1 millisecond  (even considered rounding up T as well) (shouldn't be anything wrong wtih code, more library problems?)