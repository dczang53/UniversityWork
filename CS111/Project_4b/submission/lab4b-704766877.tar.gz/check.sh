#!/bin/bash

echo "Testing: './lab4b --log=log.txt --period=2 --scale=C' with multiple STDIN options"
{ sleep 2; echo "PERIOD=1"; sleep 2; echo "SCALE=F"; sleep 2; echo "SCALE=C"; sleep 2; echo "STOP"; sleep 2; echo "LOG logging"; sleep 2; echo "START"; sleep 2; echo "OFF"; } | ./lab4b --log=log.txt --period=2 --scale=C
