{ "Z", 0, "compress", 0 },
{ "gz", 0, "gzip", 0 },
{ "svgz", 0, "gzip", 0 },
{ "uu", 0, "x-uuencode", 0 },
